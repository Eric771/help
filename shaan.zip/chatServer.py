
#!/usr/bin/python3
# Chat Program
# author: mahendra.data@ub.ac.id
# execute server: ./tugas6.5.py server <IP>:<PORT>
# execute server: ./tugas6.5.py client <Server IP>:<Server PORT> <username>
# type "/<username> <message>" to send private message

import sys
import socket
import select
import signal
import json


class Server:
    def __init__(self, sockaddr):
        # create connection socket
        self.connsock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.connsock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.connsock.bind(sockaddr)
        self.connsock.listen(1)
        print("Listen at {}...".format(self.connsock.getsockname()))

        # this dictionary contain client's username and socket
        self.users = {}

    def __broadcast__(self, datasock, payload):
        # send to all users except the sender
        for s in self.users.values():
            if s is not datasock:
                s.sendall(payload)

    def __disconnected__(self, datasock):
        print("Client {} disconnected.".format(datasock.getpeername()))
        # remove from user dictionary
        for key, val in self.users.items():
            if val is datasock:
                del self.users[key]

    def __forward__(self, datasock):
        payload = datasock.recv(2048)
        if payload:
            # get "To" username
            dst = json.loads(payload.decode("utf-8"))["To"]
            if dst == "all":
                self.__broadcast__(datasock, payload)
            else:
                # send private message
                self.users[dst].sendall(payload)
        else:
            self.__disconnected__(datasock)

    def __serve__(self, ready):
        for s in ready:
            if s is self.connsock:
                # receive connection
                datasock, peername = self.connsock.accept()
                # get username
                username = datasock.recv(2048)
                self.users[username] = datasock
                print("Client {} connected from {}.".format(username, peername))
            else:
                self.__forward__(s)

    def run(self):
        print("Press Crtl+c to stop...")
        while True:
            try:
                signal.signal(signal.SIGINT, signal.default_int_handler)
                ready, _, _ = select.select([self.connsock] + list(self.users.values()), [], [])
                self.__serve__(ready)
            except KeyboardInterrupt:
                break

        # close client's sockets
        for s in self.users.values():
            s.close()
        # close server's socket
        self.connsock.close()


class Client:
    def __init__(self, sockaddr, username):
        self.online = True
        # create socket
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.connect(sockaddr)
        # send username
        self.username = username
        self.sock.sendall(self.username.encode("utf-8"))
        print(
            "User {} connected to {} from {}.".format(self.username, self.sock.getpeername(), self.sock.getsockname()))

    def __receive__(self):
        payload = self.sock.recv(2048)
        if payload:
            # decode using utf-8 then read json data
            data = json.loads(payload.decode("utf-8"))
            print("({}) > {}".format(data["From"], data["Msg"]))
        else:
            print("Server disconnected.")
            self.online = False

    def __send__(self):
        dst = "all"
        msg = sys.stdin.readline().strip()
        if msg[0] == "/":
            msgs = msg.split(" ", 1)
            dst = msgs[0][1:]
            msg = msgs[1]

        # send json data encoded using utf-8
        self.sock.sendall(json.dumps({"From": self.username, "To": dst, "Msg": msg}).encode("utf-8"))

    def run(self):
        rlist = [self.sock, sys.stdin]
        print("Press Crtl+c to stop...")
        while self.online:
            try:
                signal.signal(signal.SIGINT, signal.default_int_handler)
                # waiting input from socker or user input
                ready, _, _ = select.select(rlist, [], [])
                for i in ready:
                    if i is self.sock:
                        self.__receive__()
                    else:
                        self.__send__()
            except KeyboardInterrupt:
                self.online = False

        # close socket
        self.sock.close()


#if __name__ == "__main__":
	#ip, port = sys.argv[2].split(":")
	#sockaddr = (ip, int(port))
	#app = Server(sockaddr) if sys.argv[1] == "server" else Client(sockaddr, sys.argv[3])
	#app.run()
#view rawchat.py hosted with ❤ by GitHub